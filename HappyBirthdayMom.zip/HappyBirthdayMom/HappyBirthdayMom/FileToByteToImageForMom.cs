﻿using System;
using System.IO;
//using SixLabors.ImageSharp;
using System.Drawing;


namespace HappyBirthdayMom
{

    class Program
    {



        static void Main(string[] args)
        {

            //Test File Path: /Users/paulotgaudin/GetBackAlbumCover.jpg

            Console.WriteLine("Hey Mom! I know that Olivia and I have already handed you a wonderful book as a present.");
            Console.WriteLine("But I thought I would make this for you as something you could keep and use to your hearts content.");
            Console.WriteLine("");
            Console.WriteLine("I made a way to make some pretty cool abstract art, out of your favorite pictures and files in general!");
            Console.WriteLine("");
            Console.WriteLine("Are you ready to try it? (y/n) ");

            string userReady = Console.ReadLine();

            try
            {
                if (userReady.Equals("Y", StringComparison.InvariantCultureIgnoreCase))
                {
                    Console.WriteLine("What File Path would you like me to use? ");
                    string InputFilePath = Console.ReadLine();





                    byte[] bytes = System.IO.File.ReadAllBytes(InputFilePath);
                    double length = Math.Sqrt((double)bytes.Length);
                    string fileBytes = BitConverter.ToString(bytes);

                    Bitmap bytMap = new Bitmap((int)length + 10, (int)length + 10);

                    //Console.WriteLine(fileBytes);

                    int index = 0;

                    Color color = Color.AliceBlue;

                    for (int x = 0; x < bytMap.Width; x++)
                    {
                        for (int y = 0; y < bytMap.Height; y++)
                        {
                            if (index < bytes.Length)
                            {
                                color = Color.FromArgb(bytes[index], bytes[index], bytes[index++]);

                            }
                            bytMap.SetPixel(x, y, color);
                        }
                    }
                    Console.WriteLine("What would you like to name your piece?");
                    string newName = Console.ReadLine();


                    Console.WriteLine("Where would you like me to save it?");
                    string newPath = Console.ReadLine();

                    bytMap.Save(newName, System.Drawing.Imaging.ImageFormat.Jpeg);






                }
            }
            catch (Exception)
            {
                Console.WriteLine("Im Sorry Mom! I thought this would work!");
            }







        }       //Open the new file.

    }






}

